//
//  HttpPostArrayInterface.m
//  MiniBuKe
//
//  Created by chenheng on 2018/5/4.
//  Copyright © 2018年 深圳偶家科技有限公司. All rights reserved.
//

#import "HttpPostArrayInterface.h"
#import "ASIFormDataRequest.h"

@implementation HttpPostArrayInterface

-(void)start
{
    if (self.url != nil && ![@"" isEqualToString:self.url]) {
        NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run) object:nil];
        [thread start];
    } else {
        onError(-1,@"url有误");
    }
}

-(void)run
{
    UIDevice *device = [UIDevice currentDevice];
    NSString *deviceName = [device model];
    
    NSURL *url = [NSURL URLWithString:self.url];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request addRequestHeader:@"User-Agent" value:deviceName];
    if (self.USER_TOKEN != nil && self.USER_TOKEN.length > 0) {
        [request addRequestHeader:@"USER_TOKEN" value:self.USER_TOKEN];
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
        NSLog(@"app_Version ===> %@ <===",app_Version);
        NSLog(@"USER_TOKEN ===> %@",self.USER_TOKEN);
        [request addRequestHeader:@"version" value:app_Version];
    }
    
    [request addRequestHeader:@"Content-Type" value:@"application/json; encoding=utf-8"];
    [request addRequestHeader:@"Accept" value:@"application/json"];
    
    request.delegate = self;
    request.requestMethod = @"POST";
    //构建post参数
    if ([self.delegate respondsToSelector:@selector(buildRequestParams)]) {
        NSArray *array = [self.delegate buildRequestParams];
        if (array != nil && array.count != 0) {
            
            if ([NSJSONSerialization isValidJSONObject:array]) {
                NSError *error;
                NSData *jsonData = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
                NSMutableData *tempJsonData = [NSMutableData dataWithData:jsonData];
                [request setPostBody:tempJsonData];
            }
        }
    }
    [request setTimeOutSeconds:TIME_OUT_SECOND];
    [self addSessionId:request];
    
    [request startAsynchronous];
}


//附加属性
- (NSString *) appendGetParams :(NSMutableDictionary *) dictionary
{
    NSString *result = self.url;
    if (dictionary != nil && dictionary.count != 0) {
        //得到词典中所有KEY值
        NSEnumerator * enumeratorKey = [dictionary keyEnumerator];
        int i = 0;
        //快速枚举遍历所有KEY的值
        for (NSObject *key in enumeratorKey) {
            //NSLog(@"遍历KEY的值: %@",key);
            if (i != 0) {
                result = [result stringByAppendingString:@"&"];
            }
            result = [result stringByAppendingString:(NSString *)key];
            result = [result stringByAppendingString:@"="];
            NSString *value = (NSString *)[dictionary objectForKey:key];
            result = [result stringByAppendingString:value];
            i ++;
        }
    }
    return result;
}

- (void) addSessionId:(ASIHTTPRequest *)request
{
    if (self.sessionId != nil && ![@"" isEqualToString:self.sessionId]) {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        self.sessionId = [NSString stringWithFormat:@"JSESSIONID=%@",self.sessionId];
        [dictionary setValue:self.sessionId forKey:@"Cookie"];
        [request setRequestHeaders:dictionary];
        
        //NSLog(@" ===> sessionId ===> %@",[request.requestHeaders objectForKey:@"Cookie"]);
    }
}

#pragma mark - ASIHTTPRequestDelegate
- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSData *data = [request responseData];
    NSString *responseStr =  [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    //把中文encode转成UTF8中文字符串
    responseStr = [responseStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    if (self.isExternalInterface) {
        [self parseExternal:responseStr];
    } else {
        [self parseInternal:responseStr];
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    onError(-1,@"链接服务器失败,请检查网络是否正常");
}

//解析外部接口
-(void) parseExternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        //创建SEL 方法
        SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
        
        //方法是否存在
        if ([self.delegate respondsToSelector:parseResponseResultSEL]){
            [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
        }
        onSuccess(self,@"请求成功");
    } else {
        onError(-1,@"返回数据错误");
    }
}

//解析内部接口
-(void) parseInternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        
        NSDictionary *deserializedDictionary = (NSDictionary *)jsonObject;
        
        id success = [deserializedDictionary objectForKey:@"success"];
        id state = [deserializedDictionary objectForKey:@"state"];
        id message = [deserializedDictionary objectForKey:@"message"];
        
        if (success != nil && [success boolValue] == YES){
            
            //创建SEL 方法
            SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
            
            //方法是否存在
            if ([self.delegate respondsToSelector:parseResponseResultSEL]){
                [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
            }
            onSuccess(self,@"返回成功");
        } else {
            onError(0,@"返回错误");
        }
    } else {
        onError(-1,@"返回数据错误");
    }
}


@end
