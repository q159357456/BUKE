//
//  HttpPostArrayInterface.h
//  MiniBuKe
//
//  Created by chenheng on 2018/5/4.
//  Copyright © 2018年 深圳偶家科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

#define ERROR_NOT_DATA 2 //没有数据
#define ERROR_NOT_LOGIN 4 //没有登陆
#define TIME_OUT_SECOND 10000

@protocol   HttpPostArrayInterfaceDelegate;

typedef void (^OnSuccess) (id,NSString *);//定义OnCloseButtonClick
typedef void (^OnError) (NSInteger,NSString*);//定义item点击blocks

@interface HttpPostArrayInterface : NSObject<ASIHTTPRequestDelegate>
{
    void (^onSuccess) (id,NSString *);
    void (^onError) (NSInteger,NSString *);
}

@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSString *sessionId;
@property (nonatomic,strong) NSString *USER_TOKEN;
@property (nonatomic,strong) id<HttpPostArrayInterfaceDelegate> delegate;
@property BOOL isExternalInterface;

//启动任务
-(void) start;

@end

@protocol HttpPostArrayInterfaceDelegate<NSObject>

//构建请求属性
- (NSArray *) buildRequestParams;

//解析结果
- (void) parseResponseResult:(NSString *) responseStr jsonObject:(id)responseJsonObject;

@end

