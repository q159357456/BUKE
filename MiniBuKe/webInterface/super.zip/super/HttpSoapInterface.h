//
//  HttpSoapInterface.h
//  JTShopManage
//
//  Created by ren fei on 13-10-10.
//  Copyright (c) 2013年 JTShopManage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

#define ERROR_NOT_DATA 2 //没有数据
#define ERROR_NOT_LOGIN 4 //没有登陆
#define TIME_OUT_SECOND 10

static NSString *SOAP_HEAD = @"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body>";


static  NSString *SOAP_END = @"</soap12:Body></soap12:Envelope>";

@protocol HttpSoapDelegate;

typedef void (^OnSuccess) (id,NSString *);//定义OnCloseButtonClick
typedef void (^OnError) (NSInteger,NSString*);//定义item点击blocks

@interface HttpSoapInterface : NSObject <ASIHTTPRequestDelegate,NSXMLParserDelegate>
{
    void (^onSuccess) (id,NSString *);
    void (^onError) (NSInteger,NSString*);
}

@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSString *sessionId;
@property (nonatomic,strong) id<HttpSoapDelegate> delegate;
@property BOOL isExternalInterface;
@property BOOL isPostRequestMethod;
@property (nonatomic,strong) NSString *postBodyStr;
@property (nonatomic,strong) NSXMLParser *xmlParser;
@property (nonatomic,strong) NSString *matchingElement;

//启动任务
-(void) start;

@end


@protocol HttpSoapDelegate <NSObject>

//构建请求属性
- (NSMutableDictionary *) buildRequestParams;

//解析结果
- (void) parseResponseResult:(NSString *) responseStr
                  jsonObject:(id)responseJsonObject;
@end
