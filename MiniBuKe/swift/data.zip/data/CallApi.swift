//
//  CallApi.swift
//  MiniBuKe
//
//  Created by chenheng on 2018/7/5.
//  Copyright © 2018年 lucky. All rights reserved.
//

import Foundation

class CallApi: NSObject {
    
    public func run() {
       TestApi().load(LoadType: .LoadFromNetworkOnly,ID:1, SuccessCallback: { (dataSource) -> (Void) in
           
           print("testApi request data = success")

           // if let object = dataSource as? TestApi {
           //     //code
           // }
           
       }) { (dataSource, error) -> (Void) in

           print("testApi request data = fail")
           // if error.code == .error_Update_data {
           //     //code
           // } else {
           //     //code
           // }
       }
    }
    
}
