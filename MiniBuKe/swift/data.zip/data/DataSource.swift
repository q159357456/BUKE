//
//  NetDataSource.swift
//
//  Created by chenheng on 18/7/2.
//  Copyright © 2018年 chenheng. All rights reserved.
//

import Foundation

#if DEBUG
    let serverHost = "http://dev.xiaobuke.com"
#else
    let serverHost = "https://www.xiaobuke.com"
#endif

public enum Method: String {
    case GET, POST
}

public enum LoadType: String {
    case LoadFromNetworkOnly, LoadFromLocalOnly,LoadLocalNetwork
}

public enum ErrorCode : Int {
    init(value:Int){
        switch(value){
        case 1:
            self = .errorSuccess
            break
        case 0x10:
            self = .errorHttpFailed
            break
        case 0x11:
            self = .errorDataParseException
            break
        case 0x12:
            self = .errorUnknown
            break
        case 500...510:
            self = .errorServerFail
            break
        case 404:
            self = .errorNetworkRequestFail
            break
        case 539299862:
            self = .error_Login_NotLogin
            break
        case 559091715:
            self = .error_Update_data
            break
        case 1003:
            self = .error_collect_upper
            break
        case 1005:
            self = .error_collect_update
            break
        case 1006:
            self = .error_collect_refresh
            break
        case 559091718:
            self = .error_update_num
            break
        case 543227935...543227938:
            self = .error_after_sale_should_show_alert
            break
        case 559091728,559091721,559091732,559091733,559091729:
            self = .error_shopping_cart_show_alert
            break
        case 559091731,559091730:
            self = .error_shopping_cart_toast
            break
        default:
            self = .errorUnknown
            break
        }
    }
    case errorSuccess                          = 1
    case errorHttpFailed                       = 0x10
    case errorDataParseException               = 0x11
    case errorUnknown                          = 0x12
    case errorServerFail                       = 500
    case errorNetworkRequestFail               = 404
    case errorReponseNotJSONData               = 100000
    case error_Login_NotLogin                  = 539299862
    case error_Update_data                     = 559091715
    case error_collect_upper                   = 1003
    case error_collect_update                  = 1005
    case error_collect_refresh                 = 1006
    case error_update_num                      = 559091718
    case error_after_sale_should_show_alert    = 543227935
    case error_shopping_cart_show_alert        = 559091728
    case error_shopping_cart_toast             = 559091729
}

struct DataError{
    var code : ErrorCode = .errorUnknown
    var descriptor : String = ""
    init(ErrorInt codeValue:Int){
        code = ErrorCode(value: codeValue)
        setDescriptor(ErrorCode: code)
    }
    init(ErrorCode codeValue:ErrorCode){
        code = codeValue
        setDescriptor(ErrorCode: code)
    }
    init(ErrorCode codeValue:ErrorCode,Msg str:String){
        code = codeValue
        descriptor = str
    }
    mutating func setDescriptor (ErrorCode codeValue:ErrorCode){
        switch(codeValue){
        case .errorSuccess:
            descriptor = "成功"
            break
        case .errorHttpFailed:
            descriptor = "网络异常,请稍后再试"
            break
        case .errorDataParseException:
            descriptor = "数据解析错误"
            break
        case .errorUnknown:
            descriptor = "未知错误"
            break
        case .errorNetworkRequestFail:
            descriptor = "网络请求失败"
            break
        case .errorReponseNotJSONData:
            descriptor = "服务器返回数据错误"
            break
        case .error_Login_NotLogin:
            descriptor = "未登录"
            break
        case .errorServerFail:
            descriptor = "服务异常,请稍后再试"
            break
        default:
            break
        }
    }
}

protocol DataSourceDelegate : NSObjectProtocol {
    func onDataLoadSuccess(DataSource dataSource: DataSource)
    func onDataLoadFail(DataSource dataSource: DataSource,DataError error:DataError)
}

protocol DataCacheProtocol : NSObjectProtocol{
    func saveData (ResponseString responseStr : String,Url url:String)
    func loadData(Url url:String)->(String?)
}

struct Static {
    static var predicate : Int = 0
    static var shareDSUserDefaults : UserDefaults?
}

class DataSource : NSObject, DataSourceDelegate,DataCacheProtocol {
    
    private static var __once: () = {
            
            Static.shareDSUserDefaults = UserDefaults(suiteName: "group.data")
            if let uf = Static.shareDSUserDefaults {
                if uf.dictionaryRepresentation().keys.count > 1000 {
                    DataSource.clearCachedData()
                }
            }
        }()
    
    var httpManager = AFHTTPSessionManager()
    fileprivate var httpTimeoutInterval = 8.0
    internal weak var delegate : DataSourceDelegate!
    internal weak var dataCache : DataCacheProtocol!
    
    internal var successCallback: ((_ DataSource : DataSource) -> (Void))?
    internal var failCallback: ((_ DataSource : DataSource,_ error:DataError) -> (Void))?
    
    internal let protocolName = "https"
    internal let domain = serverHost
    internal var portal :String = ""
    internal var params : [String : Any]?
    internal var url : String!
    internal var operationType : Method = .GET
    fileprivate var loadType: LoadType = .LoadFromNetworkOnly
    
    static let cachedUserDefaults:UserDefaults = DataSource.getShareUserDefaults()!
    internal var responseString : String?
    internal var showLog = false
    fileprivate var errorUnknownDescriptor:String = ""
    
    override init () {
        super.init()
        self.delegate = self
        self.dataCache = self
    }
    
    deinit {
        DSLog(" ==> deinit <== ")
    }
    
    init (DataSourceDelegate delegate : DataSourceDelegate, cache:DataCacheProtocol?=nil) {
        super.init()
        self.delegate = delegate
        if let kCache = cache {
            self.dataCache = kCache
        } else {
            self.dataCache = self
        }
    }
    
    func load(LoadType type:LoadType,SuccessCallback successCallback: @escaping (_ dataSource : DataSource) -> (Void),
          FailCallback failCallback: @escaping (_ dataSource : DataSource,_ error:DataError) -> (Void)) {
        
        self.successCallback = successCallback
        self.failCallback = failCallback
        
        load(LoadType: type)
    }
    
    func load(LoadType type:LoadType){
        self.loadType = type
        self.buildParams()
        self.addParams()
        
        DSLog("swift url => \(self.url)")
        
        switch(type){
        case .LoadFromNetworkOnly:
            DSLog(".LoadFromNetworkOnly")
            self.loadDataFromNetwork()
        case .LoadFromLocalOnly:
            DSLog(".LoadFromLocalOnly")
            self.loadDataFromLocal()
        default:
            DSLog(".loadDataFromLocal && .loadDataFromNetwork")
            self.loadDataFromLocal()
            self.loadDataFromNetwork()
        }
        
    }
    
    func addParams(){
        DSLog("===> DataSource - addParams <===")
        // if self.params != nil {
        //     let _ = self.params?.updateValue("1" as AnyObject, forKey: "appview")
        // } else {
        //     self.params = ["appview":"1" as AnyObject]
        // }
    }
    
    @objc dynamic fileprivate func loadDataFromNetwork () {
        self.initHttpManager()
        self.executeHttpRequest()
    }
    
    internal func loadDataFromLocal () {
        let myQueue : DispatchQueue = DispatchQueue.global(priority: .background)
        myQueue.async(execute: { () -> Void in
            if let str = self.dataCache.loadData(Url: self.url) {
                self.responseString = str
                
//                self.DSLog("self.dataCache.loadData == \(self.responseString!)")
                
                let errorCode = self.parseLocalData(self.responseString!)
                
                //在主线程中更改UI
                DispatchQueue.main.async(execute: { () -> Void in
                    self.onExecuteResult(ErrorCode: errorCode)
                })
            }
        })
    }
    
    fileprivate func initHttpManager(){
//        httpManager.requestSerializer.setValue(String(MDUtility.getUserAgentAddInfo()!), forHTTPHeaderField: "User-Agent")
//        httpManager.requestSerializer.setValue(String("USER_INFO"), forHTTPHeaderField: "User-Agent")
        httpManager.responseSerializer.acceptableContentTypes = ["text/html","text/html; charset=utf-8","image/jpeg","image/png","application/json","text/javascript","text/plain","multipart/form-data","application/x-javascript","application/json;charset=utf-8"]
        httpManager.requestSerializer.timeoutInterval = httpTimeoutInterval
        httpManager.securityPolicy = AFSecurityPolicy(pinningMode: AFSSLPinningMode.none)
        httpManager.securityPolicy.allowInvalidCertificates = true
    }
    
    internal func buildParams () {
        
    }
    
    internal func parserJson(Json json: AnyObject) {
        
    }
    
    fileprivate func onResult(Json json: AnyObject) -> (ErrorCode) {
        var errorCode = ErrorCode.errorReponseNotJSONData
    
        if let dic:NSDictionary = json as? NSDictionary {
            if let error : NSNumber = dic.object(forKey: "success") as? NSNumber {
                DSLog("error.integerValue ==>\(error.intValue)")
                if ErrorCode(value: error.intValue) == .errorSuccess {
                    errorCode = .errorSuccess
                } else {
                    if let msg = dic.object(forKey: "message") {
                        self.errorUnknownDescriptor = String(describing: msg)
                    }
                    errorCode = ErrorCode(value: error.intValue)
                }
            }
        } else if let array:NSArray = json as? NSArray {
            if array.count > 0 {
                errorCode = .errorSuccess
            }
        }
        
        if errorCode == ErrorCode.errorSuccess {
            do {
                let data = try JSONSerialization.data(withJSONObject: json, options: [])
                let str = String(data:data, encoding: String.Encoding.utf8)!.replacingOccurrences(of: "\\", with: "")
                if showLog {
                    DSLog("\(NSStringFromClass(object_getClass(self)!)) JsonString => " + str)
                }
                
                parserJson(Json:json)
            } catch {
                DSLog("\(DataError(ErrorCode: errorCode).descriptor)")

            }
        } else if errorCode == ErrorCode.errorReponseNotJSONData {
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
        }
        
        return errorCode
    }
    
    
    
    fileprivate func parseResponse (_ rawResponse : AnyObject?) -> (String?,ErrorCode) {
        var str:String? = nil
        var errorCode = ErrorCode.errorDataParseException
        if (rawResponse != nil) {
            DSLog("\(String(describing: rawResponse))")
        }
        
        do {
            if let response = rawResponse {
                let data = try JSONSerialization.data(withJSONObject: response, options: [])
                
                if let json : AnyObject? = try! JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.allowFragments) as AnyObject?? {
                    str = String(data:data, encoding: String.Encoding.utf8)!
                    errorCode = self.onResult(Json: json!)
                }
                
            }
        }
        catch {
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
        }
        
        
        if errorCode == ErrorCode.errorDataParseException {
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
        }
        
        return (str,errorCode)
    }
    
    fileprivate func parseLocalData (_ rawResponse : String?) ->(ErrorCode){
        var errorCode = ErrorCode.errorDataParseException
        DSLog("parse = \(rawResponse)")
        if let str = rawResponse {
            let nstr:NSString = NSString(format: "\(str)" as NSString)
            //            DSLog("load json \(nstr)")
            if let json:AnyObject = nstr.jsonValue() as AnyObject? {
                errorCode = self.onResult(Json: json)
            }
        }
        
        if errorCode == ErrorCode.errorDataParseException {
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
        }
        
        return errorCode
    }
    
    @objc dynamic fileprivate func executeHttpGetRequest () {
        httpManager.get(self.url, parameters: self.params,
            
            success: { (operation, response) -> Void in
                
                let myQueue : DispatchQueue = DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.default)
                myQueue.async(execute: { () -> Void in
                    let result = self.parseResponse(response as AnyObject?)
                    self.responseString = result.0
                    let errorCode = result.1
                    
                    if  errorCode == ErrorCode.errorSuccess  {
                        self.dataCache.saveData(ResponseString: self.responseString! ,Url:self.url)
                    }
                    
                    //在主线程中更改UI
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.onExecuteResult(ErrorCode: errorCode)
                    })
                    
                })
                
            },
            failure: { (operation, error) -> Void in
                let error = error as! NSError

                var errorCode = ErrorCode(value:error.code)
                if errorCode != ErrorCode.errorServerFail {
                    errorCode = ErrorCode.errorHttpFailed
                }
                self.onExecuteResult(ErrorCode: errorCode)
        })
        
    }
    
    @objc dynamic func executeHttpPostRequest () {
        
        httpManager.post(self.url, parameters: self.params,
            
            success: { (operation, response) -> Void in
                
                let myQueue : DispatchQueue = DispatchQueue.global(priority: DispatchQueue.GlobalQueuePriority.default)
                myQueue.async(execute: { () -> Void in
                    let result = self.parseResponse(response as AnyObject?)
                    self.responseString = result.0
                    let errorCode = result.1
                    
                    if  errorCode == ErrorCode.errorSuccess  {
                        self.dataCache.saveData(ResponseString: self.responseString! ,Url:self.url)
                    }
                    
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.onExecuteResult(ErrorCode: errorCode)
                    })
                    
                })
            },
            failure: { (operation, error) -> Void in
                let error = error as! NSError

                var errorCode = ErrorCode(value:error.code)
                if errorCode != ErrorCode.errorServerFail {
                    errorCode = ErrorCode.errorHttpFailed
                }
                self.onExecuteResult(ErrorCode: errorCode)
        })
    }
    
    
    @objc dynamic func executeHttpRequest () {
        switch (self.operationType) {
        case .GET:
            executeHttpGetRequest()
        case .POST:
            executeHttpPostRequest()
        }
    }
    
    func onExecuteResult(ErrorCode errorCode:ErrorCode) {
        switch errorCode {
        case ErrorCode.errorSuccess :
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
            self.executeSuccess()
        default:
            DSLog("\(DataError(ErrorCode: errorCode).descriptor)")
            executeFail(ErrorCode: errorCode)
        }
    }
    
    @objc dynamic func executeSuccess(){
        if let delegate = self.delegate {
            delegate.onDataLoadSuccess(DataSource: self)
        }
        if let successCallback = self.successCallback {
            successCallback(self)
        }
    }
    
    func executeFail(ErrorCode errorCode:ErrorCode){
        var dataError = DataError(ErrorCode: errorCode)
//        if self.errorUnknownDescriptor.length > 0 {
//            dataError = DataError(ErrorCode: errorCode,Msg: self.errorUnknownDescriptor)
//        }
        if let delegate = self.delegate {
            delegate.onDataLoadFail(DataSource: self,DataError: dataError)
        }
        if let failCallback = self.failCallback {
            failCallback(self,dataError)
        }
    }
    
    //MARK:- onNetDataSuccess - NetDataSourceDelegate数据返回成功
    @objc dynamic func onDataLoadSuccess(DataSource dataSource: DataSource) {
        DSLog("onDataLoadSuccess ：" + NSStringFromClass(object_getClass(self)!))
    }
    //MARK:- onNetDataFail - NetDataSourceDelegate数据返回失败
    func onDataLoadFail(DataSource dataSource: DataSource,DataError error:DataError) {
        DSLog("onDataLoadFail ：" + NSStringFromClass(object_getClass(self)!))
    }
    
    //MARK:- saveData - DataCacheProtocol数据存储
    @objc dynamic func saveData (ResponseString responseString : String,Url url:String) {
        // default implmentation of data cache -- save
//        DSLog("saveData == \(url) == \(responseString)")
        DataSource.cachedUserDefaults.set(responseString, forKey: url)
        DataSource.cachedUserDefaults.synchronize()
    }
    //MARK:- loadData - DataCacheProtocol数据加载
    @objc dynamic func loadData(Url url:String)->(String?){
        // default implementation of data cache -- load
        var str:String? = nil
        if let val = DataSource.cachedUserDefaults.object(forKey: url) {
            str = String(describing: val)
        }
        return str
    }
    
    func DSLog(_ items: Any...){
        if showLog {
            print("\(NSStringFromClass(object_getClass(self)!)) ==> \(items)")
        }
    }
    
    @objc dynamic static func getShareUserDefaults () -> UserDefaults? {
        _ = DataSource.__once
        return Static.shareDSUserDefaults
    }
    
    @objc dynamic static func clearCachedData () {
        
        DispatchQueue.global(priority: .background).async(execute: {
            let shareDSUserDefaults : UserDefaults? = self.getShareUserDefaults()
            
            if let uf = shareDSUserDefaults {
                for key in uf.dictionaryRepresentation().keys {
                    if key.contains("http"){
                        uf.removeObject(forKey: key)
                    }
                }
                uf.synchronize()
            }
        })
    }
    
    @objc dynamic fileprivate var dsCachedUserDefaults : UserDefaults {
        var dsCachedUserDefaults : UserDefaults? = self.dsCachedUserDefaults
        if dsCachedUserDefaults == nil {
            dsCachedUserDefaults = object_getClass(self)?.getShareUserDefaults()
        }
        return dsCachedUserDefaults!
    }
    
    
}
