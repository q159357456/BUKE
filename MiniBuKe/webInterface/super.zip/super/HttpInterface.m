//
//  HttpInterface.m
//  MapDemo
//
//  Created by ren fei on 12-12-4.
//  Copyright (c) 2012年 lucker. All rights reserved.
//

#import "HttpInterface.h"
#import "ASIFormDataRequest.h"

@implementation HttpInterface

//启动任务
-(void) start
{
    if (self.url != nil && ![@"" isEqualToString:self.url]) {
        NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run) object:nil];
        [thread start];
    } else {
        onError(-1,@"url有误");
    }
}

- (void) run
{
    UIDevice *device = [UIDevice currentDevice];
    NSString *deviceName = [device model];
    if (!self.isPostRequestMethod) {
        //构建get参数
        if ([self.delegate respondsToSelector:@selector(buildRequestParams)]) {
            NSMutableDictionary *dictionary = [self.delegate buildRequestParams];
            if (dictionary != nil && dictionary.count != 0) {
                self.url = [self appendGetParams:dictionary];
            }
        }
        
        NSLog(@" %i => Http请求 => %@",[NSThread currentThread].isMainThread,self.url);
        
        //[NSThread sleepForTimeInterval:5];//测试网络延时效应
        
        NSURL *url = [NSURL URLWithString:self.url];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        
        [request addRequestHeader:@"User-Agent" value:deviceName];
        if (self.USER_TOKEN != nil && self.USER_TOKEN.length > 0) {
            [request addRequestHeader:@"USER_TOKEN" value:self.USER_TOKEN];
            NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
            //            CFShow(infoDictionary);
            NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
            NSLog(@"app_Version ===> %@ <===",app_Version);
            [request addRequestHeader:@"version" value:app_Version];
        }
        //NSLog(@"User-Agent ==> %@",deviceName);
//        NSLog(@"UserAgentString  ====》 %@",ASIHTTPRequest.defaultUserAgentString);
        request.delegate = self;
        [request setTimeOutSeconds:TIME_OUT_SECOND];
        
        [self addSessionId:request];
        
        [request startAsynchronous];
    } else {
        NSLog(@" %i => Http请求 => %@",[NSThread currentThread].isMainThread,self.url);
        
        //[NSThread sleepForTimeInterval:5];//测试网络延时效应
        
        NSURL *url = [NSURL URLWithString:self.url];
        ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:url];
        [request addRequestHeader:@"User-Agent" value:deviceName];
        if (self.USER_TOKEN != nil && self.USER_TOKEN.length > 0) {
            [request addRequestHeader:@"USER_TOKEN" value:self.USER_TOKEN];
            NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
//            CFShow(infoDictionary);
            NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
            NSLog(@"app_Version ===> %@ <===",app_Version);
            [request addRequestHeader:@"version" value:app_Version];
        }
        if (self.isPostBody) {
            [request addRequestHeader:@"Content-Type" value:@"application/json;charset=utf-8"];
            [request addRequestHeader:@"Accept" value:@"application/json"];
        }

        request.delegate = self;
        request.requestMethod = @"POST";
        //构建post参数
        if ([self.delegate respondsToSelector:@selector(buildRequestParams)]) {
            NSMutableDictionary *dictionary = [self.delegate buildRequestParams];
            if (dictionary != nil && dictionary.count != 0) {
                [self appendPostParams:dictionary ASIFormDataRequest:request];
            }
        }
        
        [request setTimeOutSeconds:TIME_OUT_SECOND];
        [self addSessionId:request];
        
        [request startAsynchronous];
    }
    
}

- (void) addSessionId:(ASIHTTPRequest *)request
{
    if (self.sessionId != nil && ![@"" isEqualToString:self.sessionId]) {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        self.sessionId = [NSString stringWithFormat:@"JSESSIONID=%@",self.sessionId];
        [dictionary setValue:self.sessionId forKey:@"Cookie"];
        [request setRequestHeaders:dictionary];
        
        //NSLog(@" ===> sessionId ===> %@",[request.requestHeaders objectForKey:@"Cookie"]);
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    //NSLog(@" ===> 请求成功 ===> %i",self.isExternalInterface);
    
    NSData *data = [request responseData];
    NSString *responseStr =  [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    if (responseStr != nil && responseStr.length > 0 ) {
        NSLog(@"responseStr1 ==> %@",responseStr);
        //把中文encode转成UTF8中文字符串
        NSString *responseStr2 = [responseStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        if (responseStr2 != nil && responseStr2.length > 0) {
            NSLog(@"responseStr2 ==> %@",responseStr);
            
            if (self.isExternalInterface) {
                [self parseExternal:responseStr];
            } else {
                [self parseInternal:responseStr];
            }
        } else {
            if (responseStr != nil && responseStr.length > 0) {
                if (self.isExternalInterface) {
                    [self parseExternal:responseStr];
                } else {
                    [self parseInternal:responseStr];
                }
            } else {
                onError(-1,@"返回数据错误");
            }
            
        }
        
    } else {
        onError(-1,@"返回数据错误");
        //onError(-1,@"链接服务器失败,请检查网络是否正常");
    }
    
    
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    //NSLog(@" ===> 请求失败 ===> ");
    //NSError *error = [request error];
    onError(-1,@"网络异常，请检查网络是否正常");
}

//附加属性
- (NSString *) appendGetParams :(NSMutableDictionary *) dictionary
{
    NSString *result = self.url;
    if (dictionary != nil && dictionary.count != 0) {
        //得到词典中所有KEY值
        NSEnumerator * enumeratorKey = [dictionary keyEnumerator];
        int i = 0;
        //快速枚举遍历所有KEY的值
        for (NSObject *key in enumeratorKey) {
            //NSLog(@"遍历KEY的值: %@",key);
            if (i != 0) {
                result = [result stringByAppendingString:@"&"];
            }
            result = [result stringByAppendingString:(NSString *)key];
            result = [result stringByAppendingString:@"="];
            NSString *value = (NSString *)[dictionary objectForKey:key];
            result = [result stringByAppendingString:value];
            i ++;
        }
    }
    return result;
}

- (void) appendPostParams :(NSMutableDictionary *) dictionary ASIFormDataRequest:(ASIFormDataRequest *) request
{
    if (self.isPostBody) {
        if (dictionary != nil && dictionary.count != 0) {
            if ([NSJSONSerialization isValidJSONObject:dictionary])
            {
                NSError *error;
                NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:NSJSONWritingPrettyPrinted error: &error];
                NSMutableData *tempJsonData = [NSMutableData dataWithData:jsonData];
                //[request setPostBody:@"{\"infoContent\": \"string\",\"infoType\": \"string\"}"];
                [request setPostBody:tempJsonData];
                NSLog(@"setPostBody ==> %@",jsonData);
            }
        }
    } else {
        if (dictionary != nil && dictionary.count != 0) {
            //得到词典中所有KEY值
            NSEnumerator * enumeratorKey = [dictionary keyEnumerator];
            
            //快速枚举遍历所有KEY的值
            for (NSObject *k in enumeratorKey) {
                //NSLog(@"遍历KEY的值: %@",key);
                NSString *key = (NSString *)k;
                NSString *value = (NSString *)[dictionary objectForKey:key];
                NSLog(@"%@ = %@",key,value);
                [request setPostValue:value forKey:key];
                
            }
        }
    }
    
}

//解析内部接口
-(void) parseInternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    //NSLog(@" jsonObject ===> %@ || error ====> %@",jsonObject,error);
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        
        NSDictionary *deserializedDictionary = (NSDictionary *)jsonObject;
        
//        id returnFlagId = [deserializedDictionary objectForKey:@"status"];
//        id returnMsgId = [deserializedDictionary objectForKey:@"result"];
        
        id success = [deserializedDictionary objectForKey:@"success"];
        id state = [deserializedDictionary objectForKey:@"state"];
        id message = [deserializedDictionary objectForKey:@"message"];
        
        //NSLog(@"returnMsg ==> %@",(NSString *)returnMsgId);
        //NSLog(@"returnFlag ==> %i",[returnFlagId integerValue]);
        
        if (success != nil && [success boolValue] == YES){
            
            //创建SEL 方法
            SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
            
            //方法是否存在
            if ([self.delegate respondsToSelector:parseResponseResultSEL]){
                [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
            }
            onSuccess(self,@"返回成功");
        } else {
            //NSLog(@"result ==> %@",returnMsgId);
            if (state != nil && message != nil) {
                onError([state integerValue],message);
            } else {
                onError(0,@"数据异常，请重试");
            }
            
        }
        
//        id returnMsgId = [deserializedDictionary objectForKey:@"returnMsg"];
//        id returnFlagId = [deserializedDictionary objectForKey:@"status"];
//        
//        //NSLog(@"returnMsg ==> %@",(NSString *)returnMsgId);
//        //NSLog(@"returnFlag ==> %i",[returnFlagId integerValue]);
//        
//        if (returnMsgId != nil && [returnMsgId isKindOfClass:[NSString class]]
//            && returnFlagId != nil && [returnFlagId integerValue] == 1){
//            
//            //创建SEL 方法
//            SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
//            
//            //方法是否存在
//            if ([self.delegate respondsToSelector:parseResponseResultSEL]){
//                [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
//            }
//            onSuccess(self,(NSString *)returnMsgId);
//        } else {
//            onError([returnFlagId integerValue],(NSString *)returnMsgId);
//        }
    } else {
        onError(-1,@"数据异常,请重试");
    }
    
}

//解析外部接口
-(void) parseExternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        //创建SEL 方法
        SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
        
        //方法是否存在
        if ([self.delegate respondsToSelector:parseResponseResultSEL]){
            [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
        }
        onSuccess(self,@"请求成功");
    } else {
        onError(-1,@"数据异常，请重试");
    }
}
@end
