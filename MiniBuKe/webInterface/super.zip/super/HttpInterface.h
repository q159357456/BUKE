//
//  HttpInterface.h
//  MapDemo
//
//  Created by ren fei on 12-12-4.
//  Copyright (c) 2012年 lucker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

#define ERROR_NOT_DATA 2 //没有数据
#define ERROR_NOT_LOGIN 4 //没有登陆
#define TIME_OUT_SECOND 10000

@protocol HttpInterfaceDelegate;

typedef void (^OnSuccess) (id,NSString *);//定义OnCloseButtonClick
typedef void (^OnError) (NSInteger,NSString*);//定义item点击blocks

@interface HttpInterface : NSObject <ASIHTTPRequestDelegate>
{
    void (^onSuccess) (id,NSString *);
    void (^onError) (NSInteger,NSString*);
}

@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSString *sessionId;
@property (nonatomic,strong) NSString *USER_TOKEN;


@property (nonatomic,strong) id<HttpInterfaceDelegate> delegate;
@property BOOL isExternalInterface;
@property BOOL isPostRequestMethod;
//@property BOOL isPostFormData;
@property BOOL isPostBody;
//启动任务
-(void) start;

@end


@protocol HttpInterfaceDelegate <NSObject>

//构建请求属性
- (NSMutableDictionary *) buildRequestParams;

//解析结果
- (void) parseResponseResult:(NSString *) responseStr
    jsonObject:(id)responseJsonObject;
@end

