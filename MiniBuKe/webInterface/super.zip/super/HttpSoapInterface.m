//
//  HttpSoapInterface.m
//  JTShopManage
//
//  Created by ren fei on 13-10-10.
//  Copyright (c) 2013年 JTShopManage. All rights reserved.
//

#import "HttpSoapInterface.h"
#import "ASIFormDataRequest.h"
@interface HttpSoapInterface ()

@property (nonatomic) BOOL elementFound;
@property (nonatomic,strong) NSString *soapResults;

@end
@implementation HttpSoapInterface

//启动任务
-(void) start
{
    if (self.url != nil && ![@"" isEqualToString:self.url]) {
        NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run) object:nil];
        [thread start];
    } else {
        onError(-1,@"url有误");
    }
}

- (void) run
{
    UIDevice *device = [UIDevice currentDevice];
    NSString *deviceName = [device model];
    if (!self.isPostRequestMethod) {
        //构建get参数
        if ([self.delegate respondsToSelector:@selector(buildRequestParams)]) {
            NSMutableDictionary *dictionary = [self.delegate buildRequestParams];
            if (dictionary != nil && dictionary.count != 0) {
                self.url = [self appendGetParams:dictionary];
            }
        }
        
        NSLog(@" %i => Http请求 => %@",[NSThread currentThread].isMainThread,self.url);
        
        //[NSThread sleepForTimeInterval:5];//测试网络延时效应
        
        NSURL *url = [NSURL URLWithString:self.url];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        
        [request addRequestHeader:@"User-Agent" value:deviceName];
        //NSLog(@"User-Agent ==> %@",deviceName);
        //        NSLog(@"UserAgentString  ====》 %@",ASIHTTPRequest.defaultUserAgentString);
        request.delegate = self;
        [request setTimeOutSeconds:TIME_OUT_SECOND];
        
        [self addSessionId:request];
        
        [request startAsynchronous];
    } else {
        NSLog(@" %i => Http请求 => %@",[NSThread currentThread].isMainThread,self.url);
        
        //[NSThread sleepForTimeInterval:5];//测试网络延时效应
        
        NSURL *url = [NSURL URLWithString:self.url];
        ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:url];
        [request addRequestHeader:@"User-Agent" value:deviceName];
        //NSLog(@"User-Agent ==> %@",deviceName);
        request.delegate = self;
        request.requestMethod = @"POST";
        //构建post参数
        if ([self.delegate respondsToSelector:@selector(buildRequestParams)]) {
            NSMutableDictionary *dictionary = [self.delegate buildRequestParams];
            if (dictionary != nil && dictionary.count != 0) {
                [self appendPostParams:dictionary ASIFormDataRequest:request];
            }
        }
        [request setTimeOutSeconds:TIME_OUT_SECOND];
        
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        [dictionary setValue:@"text/xml" forKey:@"Content-Type"];
        //[dictionary setValue:@"http://tempurl.org/of_login" forKey:@"SOAPAction"];
        [dictionary setValue:[NSNumber numberWithInt:self.postBodyStr.length] forKey:@"Content-Length"];
        [dictionary setValue:@"gzip" forKey:@"Accept-Encoding"];
        
        [request setRequestHeaders:dictionary];
        
        //NSLog(@"%@",self.postBodyStr);
        NSMutableData *mData = [NSMutableData dataWithBytes:[self.postBodyStr cStringUsingEncoding:NSUTF8StringEncoding] length:[self.postBodyStr length]];
        [request setPostBody:mData];
        
        
        [request startAsynchronous];
    }
    
}

- (void) addSessionId:(ASIHTTPRequest *)request
{
    if (self.sessionId != nil && ![@"" isEqualToString:self.sessionId]) {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        self.sessionId = [NSString stringWithFormat:@"JSESSIONID=%@",self.sessionId];
        [dictionary setValue:self.sessionId forKey:@"Cookie"];
        [request setRequestHeaders:dictionary];
        
        //NSLog(@" ===> sessionId ===> %@",[request.requestHeaders objectForKey:@"Cookie"]);
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    //NSLog(@" ===> 请求成功 ===> %i",self.isExternalInterface);
    
    NSData *data = [request responseData];
    NSString *responseStr =  [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    //把中文encode转成UTF8中文字符串
    responseStr = [responseStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSLog(@"super responseStr ==> %@",responseStr);
    
    if (responseStr != nil && ![@"" isEqualToString:responseStr]) {
        self.xmlParser = [[NSXMLParser alloc] initWithData: data];
        [self.xmlParser setDelegate:self];
        [self.xmlParser setShouldResolveExternalEntities: YES];
        [self.xmlParser parse];
        
        if (self.soapResults != nil && ![@"" isEqualToString:self.soapResults]) {
            self.soapResults = [self.soapResults stringByReplacingOccurrencesOfString:@"\\" withString:@"|"];
            NSData* jsonData = [self.soapResults dataUsingEncoding:NSUTF8StringEncoding];
            NSError *error = nil;
            id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
            
            if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
                NSDictionary *deserializedDictionary = (NSDictionary *)jsonObject;
                
//                id returnFlagId = [deserializedDictionary objectForKey:@"return"];
//                id returnMsgId = [deserializedDictionary objectForKey:@"result"];
                
                id success = [deserializedDictionary objectForKey:@"success"];
                id state = [deserializedDictionary objectForKey:@"state"];
                id message = [deserializedDictionary objectForKey:@"message"];
                //id data = [deserializedDictionary objectForKey:@"data"];
                
                //NSLog(@"returnMsg ==> %@",(NSString *)returnMsgId);
                //NSLog(@"returnFlag ==> %i",[returnFlagId integerValue]);
                
                //if (returnFlagId != nil && [returnFlagId integerValue] == 1){
                if (success != nil && [success boolValue] == YES){
                    //创建SEL 方法
                    SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
                    
                    //方法是否存在
                    if ([self.delegate respondsToSelector:parseResponseResultSEL]){
                        [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
                    }
                    onSuccess(self,@"success");
                } else {
                    //NSLog(@"result ==> %@",returnMsgId);
                    onError(0,0);
                }
            } else {
                onError(-1,@"返回数据错误");
            }
        } else {
            onError(-1,@"返回数据错误");
        }
    } else {
        onError(-1,@"返回数据错误");
    }
    
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    //NSLog(@" ===> 请求失败 ===> ");
    //NSError *error = [request error];
    onError(-1,@"链接服务器失败,请检查网络是否正常");
}

//附加属性
- (NSString *) appendGetParams :(NSMutableDictionary *) dictionary
{
    NSString *result = self.url;
    if (dictionary != nil && dictionary.count != 0) {
        //得到词典中所有KEY值
        NSEnumerator * enumeratorKey = [dictionary keyEnumerator];
        int i = 0;
        //快速枚举遍历所有KEY的值
        for (NSObject *key in enumeratorKey) {
            //NSLog(@"遍历KEY的值: %@",key);
            if (i != 0) {
                result = [result stringByAppendingString:@"&"];
            }
            result = [result stringByAppendingString:(NSString *)key];
            result = [result stringByAppendingString:@"="];
            NSString *value = (NSString *)[dictionary objectForKey:key];
            result = [result stringByAppendingString:value];
            i ++;
        }
    }
    return result;
}

- (void) appendPostParams :(NSMutableDictionary *) dictionary ASIFormDataRequest:(ASIFormDataRequest *) request
{
    if (dictionary != nil && dictionary.count != 0) {
        //得到词典中所有KEY值
        NSEnumerator * enumeratorKey = [dictionary keyEnumerator];
        
        //快速枚举遍历所有KEY的值
        for (NSObject *k in enumeratorKey) {
            //NSLog(@"遍历KEY的值: %@",key);
            NSString *key = (NSString *)k;
            NSString *value = (NSString *)[dictionary objectForKey:key];
            NSLog(@"%@ = %@",key,value);
            [request setPostValue:value forKey:key];
        }
    }
}

//解析内部接口
-(void) parseInternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    //NSLog(@" jsonObject ===> %@ || error ====> %@",jsonObject,error);
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        
        NSDictionary *deserializedDictionary = (NSDictionary *)jsonObject;
        
//        id returnFlagId = [deserializedDictionary objectForKey:@"status"];
//        id returnMsgId = [deserializedDictionary objectForKey:@"result"];
        
        id success = [deserializedDictionary objectForKey:@"success"];
        id state = [deserializedDictionary objectForKey:@"state"];
        id message = [deserializedDictionary objectForKey:@"message"];
        
        //NSLog(@"returnMsg ==> %@",(NSString *)returnMsgId);
        //NSLog(@"returnFlag ==> %i",[returnFlagId integerValue]);
        
        if (success != nil && [success boolValue] == YES){
            
            //创建SEL 方法
            SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
            
            //方法是否存在
            if ([self.delegate respondsToSelector:parseResponseResultSEL]){
                [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
            }
            onSuccess(self,@"返回成功");
        } else {
            //NSLog(@"result ==> %@",returnMsgId);
            onError(0,0);
        }
        
        //        id returnMsgId = [deserializedDictionary objectForKey:@"returnMsg"];
        //        id returnFlagId = [deserializedDictionary objectForKey:@"status"];
        //
        //        //NSLog(@"returnMsg ==> %@",(NSString *)returnMsgId);
        //        //NSLog(@"returnFlag ==> %i",[returnFlagId integerValue]);
        //
        //        if (returnMsgId != nil && [returnMsgId isKindOfClass:[NSString class]]
        //            && returnFlagId != nil && [returnFlagId integerValue] == 1){
        //
        //            //创建SEL 方法
        //            SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
        //
        //            //方法是否存在
        //            if ([self.delegate respondsToSelector:parseResponseResultSEL]){
        //                [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
        //            }
        //            onSuccess(self,(NSString *)returnMsgId);
        //        } else {
        //            onError([returnFlagId integerValue],(NSString *)returnMsgId);
        //        }
    } else {
        onError(-1,@"返回数据错误");
    }
}

//解析外部接口
-(void) parseExternal:(NSString *) responseStr
{
    NSData* jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];//&error表示地址传递
    if (jsonObject != nil && error == nil && [jsonObject isKindOfClass:[NSDictionary class]]){
        //创建SEL 方法
        SEL parseResponseResultSEL= @selector(parseResponseResult: jsonObject:);
        
        //方法是否存在
        if ([self.delegate respondsToSelector:parseResponseResultSEL]){
            [self.delegate parseResponseResult:responseStr jsonObject:jsonObject];
        }
        onSuccess(self,@"请求成功");
    } else {
        onError(-1,@"返回数据错误");
    }
}

#pragma mark -
#pragma mark XML Parser Delegate Methods

// 开始解析一个元素名
-(void) parser:(NSXMLParser *) parser didStartElement:(NSString *) elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *) qName attributes:(NSDictionary *) attributeDict {
    if ([elementName isEqualToString:self.matchingElement]) {
        if (!self.soapResults) {
            self.soapResults = [[NSMutableString alloc] init];
        }
        self.elementFound = YES;
    }
    
}

// 追加找到的元素值，一个元素值可能要分几次追加
-(void)parser:(NSXMLParser *) parser foundCharacters:(NSString *)string {
    if (self.elementFound) {
        self.soapResults = [self.soapResults stringByAppendingString: string];
    }
    
}

// 结束解析这个元素名
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    if ([elementName isEqualToString:self.matchingElement]) {
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"手机号码信息"
//                                                        message:[NSString stringWithFormat:@"%@", self.soapResults]
//                                                       delegate:self
//                                              cancelButtonTitle:@"确定"
//                                              otherButtonTitles:nil];
//        [alert show];
        
        self.elementFound = NO;
        // 强制放弃解析
        [self.xmlParser abortParsing];
    }
}

// 解析整个文件结束后
- (void)parserDidEndDocument:(NSXMLParser *)parser {
    if (self.soapResults) {
        //self.soapResults = nil;
    }
}

// 出错时，例如强制结束解析
- (void) parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
    if (self.soapResults) {
        //self.soapResults = nil;
    }
}
@end
