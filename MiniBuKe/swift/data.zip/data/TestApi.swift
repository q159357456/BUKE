//
//  TestApi.swift
//  MiniBuKe
//
//  Created by chenheng on 2018/7/5.
//  Copyright © 2018年 lucky. All rights reserved.
//

import Foundation

class TestApi : DataSource {
    
    var id = 0
    
    func load(LoadType type:LoadType,ID id:Int,SuccessCallback successCallback: @escaping (_ dataSource : DataSource) -> (Void),
              FailCallback failCallback: @escaping (_ dataSource : DataSource,_ error:DataError) -> (Void)) {
        self.id = id
        self.successCallback = successCallback
        self.failCallback = failCallback
        
        load(LoadType: type)
    }
    
    @objc dynamic override func buildParams() {
        
        self.showLog = true
        self.operationType = .GET
        self.portal = "/pub/getAppTab"
        self.url = "\(self.domain)\(self.portal)"
        // self.params = ["id":id as AnyObject]
        
    }
    
    
    
    @objc dynamic override func parserJson(Json json: AnyObject) {
        
    }
}
